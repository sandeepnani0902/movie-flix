
import './App.css'
import Login from './components/forms/Login'
import Register from './components/forms/Register'
// import Register from './components/forms/Register'
function App() {

  return (
    <div className='app'>
      <Login />
      {/* <Register /> */}
    </div>
  )
}

export default App
