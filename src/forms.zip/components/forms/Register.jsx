import React, { useRef, useState,useEffect } from 'react'
import './register.css'
// import bodybg from '../assets/bodybg'
function Register() {

    const [form, setForm] = useState({
        firstname:"",
        lastname:"",
        email:"",
        mobile:"",
        password:"",
        confirmpassword:"",
        profile:""
    })


    
        const [error, setError] = useState("")
    
    const profile = useRef()

    const [preview, setPreview] = useState(null);

  function setUserProfile(e){
    e.preventDefault()
    console.log(firstname)
  }


function handleform(e){
    e.preventDefault()
    console.log(form)
    
}


function handleImageUpload(event){
    const file = event.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      setPreview(imageUrl);
    }
  
}

function handleinput(e){
     const { name, value } = e.target;
    setForm((prev) => ({ ...prev, [name]: value }));
    setForm()
    
}
    useEffect(() => {
        // console.log(form)
    }, [form]);



  return (
    <>
        <div className='Register'>
            <div className='form-block'>
                <form onSubmit={handleform}>
                <div className='profile'>
                    <div className='image-block'> 
                        {preview ? (
                            <img src={preview} alt="Profile" style={{width:"100px" , height:"100px", borderRadius:"50%"}} className="profile-image" />
                            ) : (
                            <svg id="camera" width="32" height="29" viewBox="0 0 32 29" fill="none" xmlns="http://www.w3.org/2000/svg">
                                <path d="M26.1818 8.7V5.8H23.2727V2.9H26.1818V0H29.0909V2.9H32V5.8H29.0909V8.7H26.1818ZM14.5455 23.925C16.3636 23.925 17.9093 23.2909 19.1825 22.0226C20.4558 20.7543 21.0919 19.2135 21.0909 17.4C21.0899 15.5865 20.4538 14.0461 19.1825 12.7788C17.9113 11.5115 16.3656 10.8769 14.5455 10.875C12.7253 10.8731 11.1801 11.5077 9.90982 12.7788C8.63952 14.05 8.00291 15.5904 8 17.4C7.99709 19.2096 8.6337 20.7505 9.90982 22.0226C11.1859 23.2947 12.7312 23.9289 14.5455 23.925ZM14.5455 21.025C13.5273 21.025 12.6667 20.6746 11.9636 19.9737C11.2606 19.2729 10.9091 18.415 10.9091 17.4C10.9091 16.385 11.2606 15.5271 11.9636 14.8262C12.6667 14.1254 13.5273 13.775 14.5455 13.775C15.5636 13.775 16.4242 14.1254 17.1273 14.8262C17.8303 15.5271 18.1818 16.385 18.1818 17.4C18.1818 18.415 17.8303 19.2729 17.1273 19.9737C16.4242 20.6746 15.5636 21.025 14.5455 21.025ZM2.90909 29C2.10909 29 1.42448 28.7163 0.855273 28.1488C0.286061 27.5814 0.000969697 26.8985 0 26.1V8.7C0 7.9025 0.285091 7.22003 0.855273 6.6526C1.42545 6.08517 2.11006 5.80097 2.90909 5.8H7.49091L10.1818 2.9H20.3636V8.7H23.2727V11.6H29.0909V26.1C29.0909 26.8975 28.8063 27.5804 28.2371 28.1488C27.6679 28.7172 26.9828 29.001 26.1818 29H2.90909Z" fill="black"/>
                            </svg>
                            )}
                    </div>
                    <div className='file-upload-loc'>
                          <input type="file" accept='image/*' name='file' id="profile" ref={profile} onChange={handleImageUpload} style={{display:"none"}}/>
                          <label htmlFor="profile" >Upload Image</label>
                          
                    </div>                  
                </div>
                <div id='field'>
                    <label>First Name <span>:</span></label>
                    <input type="text" name='firstname' placeholder='Enter User Name' onChange={handleinput}/>
                    
                </div>
                <span>{error.firstname && "enter valid name"}</span>
                <div id='field'>
                    <label>Last Name <span>:</span></label>
                    <input type="text" name='lastname'  placeholder='Enter Last Name'  onChange={handleinput}/>
                </div>
                <div  id='field'>
                    <label>Email Name <span>:</span></label>
                    <input type="email" name='email' placeholder='Enter e-mail'  onChange={handleinput}/>
                </div>
                <div id='field'>
                    <label>Mobile No <span>:</span></label>
                    <input type="text" name='mobile'  placeholder='Enter 8 digits Password' onChange={handleinput}/>
                </div>
                <div className='mobile' id='field'>
                    <label>Password <span>:</span></label>
                    <input type="password" name='password' placeholder='Enter number'  onChange={handleinput}/>
                </div>
                
              
                <div id='field'>
                    <label>Confirm Password <span>:</span></label>
                    <input type="password" name='confirmpassword'  placeholder='Re-enter Password' onChange={handleinput}/>
                </div>
                
               
                <button type='submit' id='sign-btn'>Sign In</button>
               
                <div id='sign_in'>
                    <span>Already have an account </span>
                    <a href="#">Sign In</a>
                </div>
                
                
            </form>
            </div>
        </div>
    </>

  )
}

export default Register